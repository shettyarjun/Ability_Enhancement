Arduino-MPU6050
===============

MPU6050 Triple Axis Gyroscope & Accelerometer Arduino Library.

![MPU6050 Processing](http://www.jarzebski.pl/media/zoom/publish/2014/10/mpu6050-processing-2.png "MPU6050 Processing")

Tutorials: http://www.jarzebski.pl/arduino/czujniki-i-sensory/3-osiowy-zyroskop-i-akcelerometr-mpu6050.html

This library use I2C to communicate, 2 pins are required to interface
